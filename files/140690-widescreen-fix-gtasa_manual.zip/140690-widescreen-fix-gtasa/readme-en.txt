Widescreen Fix
-------------------------------------------------------------
Мод исправляет проблемы с широкоформатными мониторами. Теперь на таких мониторах HUD игры больше не будет растягиваться. Работоспособность гарантируется только на стандартном HUD'е.

Особенности:
- Поддерживает все разрешения 
- Фиксирует HUD
- Фиксирует поле зрения 
- Фиксирует AR 
- Исправляет растянутые короны
Требуется gta_sa.exe 1.0 us и ASI Loader.
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author: ThirteenAG
Was added to the site by user: Maksim45
{tag_tag} ASI plugins
-------------------------------------------------------------
2) Copying files:
All contents of the folder "To copy to game folder" copy into the game folder confirming the replacement.

(!) If You wish to be able to remove a modification, make sure You save original copies of the replaced files safely.
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
