Widescreen Fix
-------------------------------------------------------------
Мод исправляет проблемы с широкоформатными мониторами. Теперь на таких мониторах HUD игры больше не будет растягиваться. Работоспособность гарантируется только на стандартном HUD'е.

Особенности:
- Поддерживает все разрешения 
- Фиксирует HUD
- Фиксирует поле зрения 
- Фиксирует AR 
- Исправляет растянутые короны
Требуется gta_sa.exe 1.0 us и ASI Loader.
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Der Autor: ThirteenAG
Auf der Site vom Benutzer hinzugefuegt wurde: Maksim45
{tag_tag} ASI plugins
-------------------------------------------------------------
2) Kopieren von Dateien:
Alle Inhalte des Ordners "To copy to game folder" Kopieren Sie in den Spiel-Ordner den Ersatz bestaetigt.

(!) Wenn Sie in der Lage sein, die Aenderung zu entfernen, stellen Sie sicher, dass Sie die Original-Kopien ersetzten Dateien an einem sicheren Ort erhalten.
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
