BMW X3 M40i
-------------------------------------------------------------
Installation Anleitung:
-------------------------------------------------------------
1) Der Autor: Akuma Mods
Auf der Site vom Benutzer hinzugefuegt wurde: lk_1997_kl
Ersetzt: Huntley
-------------------------------------------------------------
2) Importieren von Dateien in das Spiel-Archiv:
Mit dem Programm IMGTool 2.0 oder Crazy IMG Editor importieren Sie Dateien aus einem Ordner "To import to gta3.img" im Archiv [Ordner mit dem Spiel]\models\gta3.img

Die Download-Link fuer IMGTool 2.0 ist hier: https://GameModding.com/en/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor hier: https://GameModding.com/en/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
3) Replacement-Optionen fuer den Transport (Nehmen Sie Aenderungen an Textdateien):

in der Datei - [Installationsordner]\data\handling.cfg
Ersetzen Sie die Zeile mit den Einstellungen mit:
HUNTLEY 2500.0    6000.0   2.5    0.0 0.0 -0.20 80  0.62 0.89 0.5  	5 160.0 25.0 25.0 4 P 	7.0   0.45 0 35.0  	1.0  0.05  0.0   0.45 -0.21 0.45 0.3		0.44 0.35 40000 	20			4404		0  1	0

in der Datei - [Installationsordner]\data\vehicles.ide
Ersetzen Sie die Zeile mit den Einstellungen mit:
579,	huntley, 	huntley, 	car,		HUNTLEY, 	HUNTLEY, null,	richfamily,		6,	7,	0,	-1, 0.90, 0.90,		0

in der Datei - [Installationsordner]\data\carmods.dat
Ersetzen Sie die Zeile mit den Einstellungen mit:
huntley, nto_b_l, nto_b_s, nto_b_tw

in der Datei - [Installationsordner]\data\carcols.dat
Ersetzen Sie die Zeile mit den Einstellungen mit:
huntley, 37,37, 42,42, 53,53, 62,62, 7,7, 10,10, 11,11, 15,15
-------------------------------------------------------------
Diese Modifikation wurde von der Website https://GameModding.com/en/ heruntergeladen\r\nFolgen Sie uns in den sozialen Netzwerken!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
