BMW X3 M40i
-------------------------------------------------------------
Инструкция по установке:
-------------------------------------------------------------
1) Автор: Akuma Mods
На сайт добавил пользователь: lk_1997_kl
Заменяет: Huntley
-------------------------------------------------------------
2) Импорт файлов в IMG архив:
С помощью программы IMGTool 2.0 или Crazy IMG Editor импортируйте файлы из папки "To import to gta3.img" в архив [Папка с игрой]\models\gta3.img

IMGTool 2.0 Вы можете скачать тут: https://GameModding.com/ru/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor тут: https://GameModding.com/ru/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
3) Замена настроек для транспорта (Внесите изменения в текстовые файлы):

В файле - [Папка с игрой]\data\handling.cfg
Замените строки с настройками на:
HUNTLEY 2500.0    6000.0   2.5    0.0 0.0 -0.20 80  0.62 0.89 0.5  	5 160.0 25.0 25.0 4 P 	7.0   0.45 0 35.0  	1.0  0.05  0.0   0.45 -0.21 0.45 0.3		0.44 0.35 40000 	20			4404		0  1	0

В файле - [Папка с игрой]\data\vehicles.ide
Замените строки с настройками на:
579,	huntley, 	huntley, 	car,		HUNTLEY, 	HUNTLEY, null,	richfamily,		6,	7,	0,	-1, 0.90, 0.90,		0

В файле - [Папка с игрой]\data\carmods.dat
Замените строки с настройками на:
huntley, nto_b_l, nto_b_s, nto_b_tw

В файле - [Папка с игрой]\data\carcols.dat
Замените строки с настройками на:
huntley, 37,37, 42,42, 53,53, 62,62, 7,7, 10,10, 11,11, 15,15
-------------------------------------------------------------
Эта модификация была скачана с сайта https://GameModding.com/
Присоединяйтесь к нам в социальных сетях!
http://vk.com/gamemoddingnet
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
