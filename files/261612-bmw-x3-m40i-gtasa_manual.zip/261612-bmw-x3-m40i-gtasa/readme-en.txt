BMW X3 M40i
-------------------------------------------------------------
Installation instructions:
-------------------------------------------------------------
1) Author: Akuma Mods
Was added to the site by user: lk_1997_kl
Replace: Huntley
-------------------------------------------------------------
2) Importing files into the game archive:
With the IMGTool 2.0 or Crazy IMG Editor program import files from the folder "To import to gta3.img" in the archive [Game folder]\models\gta3.img

You can download IMGTool 2.0 here: https://GameModding.com/en/gta-san-andreas/gta-sa-programms/829-imgtool-20.html
Crazy IMG Editor here:  https://GameModding.com/en/gta-san-andreas/gta-sa-programms/828-gta-san-andreas-crazy-img-editor.html
-------------------------------------------------------------
3) Replacement options for transport (Make changes to text files):

in the file - [Game folder]\data\handling.cfg
Replace the lines with the settings with:
HUNTLEY 2500.0    6000.0   2.5    0.0 0.0 -0.20 80  0.62 0.89 0.5  	5 160.0 25.0 25.0 4 P 	7.0   0.45 0 35.0  	1.0  0.05  0.0   0.45 -0.21 0.45 0.3		0.44 0.35 40000 	20			4404		0  1	0

in the file - [Game folder]\data\vehicles.ide
Replace the lines with the settings with:
579,	huntley, 	huntley, 	car,		HUNTLEY, 	HUNTLEY, null,	richfamily,		6,	7,	0,	-1, 0.90, 0.90,		0

in the file - [Game folder]\data\carmods.dat
Replace the lines with the settings with:
huntley, nto_b_l, nto_b_s, nto_b_tw

in the file - [Game folder]\data\carcols.dat
Replace the lines with the settings with:
huntley, 37,37, 42,42, 53,53, 62,62, 7,7, 10,10, 11,11, 15,15
-------------------------------------------------------------
This modification was downloaded from https://GameModding.com/ website
Follow us in social networks!
http://vk.com/gamemoddingcom
https://twitter.com/GameModdingNet
http://www.facebook.com/gamemodding
http://www.youtube.com/user/GameModdingPreview
